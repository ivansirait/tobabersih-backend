// src/services/validationService.ts
import FormData from 'form-data';
import fetch from 'node-fetch';
import fs from 'fs';
import path from 'path';

const ML_API_URL = process.env.ML_API_URL || 'http://localhost:5001';

export interface ValidationResult {
  status: string;
  prediction: {
    class: 0 | 1;
    label: 'Tidak Layak' | 'Layak Diangkut';
    confidence: number;
    probabilities: {
      0: number;
      1: number;
    };
  };
  detection_count: number;
  features: {
    coverage_percent: number;
    object_count: number;
    height_ratio: number;
    distribution_score: number;
    bulky_flag: number;
    avg_confidence: number;
  };
}

export async function validateWasteImage(imageBuffer: Buffer, originalname: string): Promise<ValidationResult> {
  const formData = new FormData();
  formData.append('file', imageBuffer, {
    filename: originalname,
    contentType: 'image/jpeg',
  });

  const response = await fetch(`${ML_API_URL}/validate`, {
    method: 'POST',
    body: formData,
    headers: formData.getHeaders(),
  });

  if (!response.ok) {
    throw new Error(`ML API error: ${response.status} ${response.statusText}`);
  }

  const result = await response.json();
  return result;
}